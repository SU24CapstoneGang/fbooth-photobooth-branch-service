﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoboothBranchService.Application.Common.Enum
{
    public enum ServiceTypeForInput
    {
        ClothingRental = 3,
        Drinking = 4,
        MakeupKitRental = 5,
        Other = 6,
    }
}
