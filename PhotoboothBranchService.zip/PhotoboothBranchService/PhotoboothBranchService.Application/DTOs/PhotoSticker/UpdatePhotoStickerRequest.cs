﻿namespace PhotoboothBranchService.Application.DTOs.PhotoSticker
{
    public class UpdatePhotoStickerRequest
    {
        public short? Quantity { get; set; }
    }
}
