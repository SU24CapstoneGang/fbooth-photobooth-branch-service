﻿namespace PhotoboothBranchService.Application.DTOs.Authentication
{
    public class RefreshTokenRequestModel
    {
        public string RefreshToken { get; set; }
    }
}
