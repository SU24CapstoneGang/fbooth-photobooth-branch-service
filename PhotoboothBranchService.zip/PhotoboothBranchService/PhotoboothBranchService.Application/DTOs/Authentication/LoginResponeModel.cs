﻿namespace PhotoboothBranchService.Application.DTOs.Authentication
{
    public class LoginResponeModel
    {
        public string TokenId { get; set; }
        public string RefreshToken { get; set; }
    }
}
