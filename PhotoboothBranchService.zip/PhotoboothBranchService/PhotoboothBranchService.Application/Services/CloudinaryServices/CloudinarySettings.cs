﻿namespace PhotoboothBranchService.Application.Services.CloudinaryServices
{
    public class CloudinarySettings
    {
        public string CloudName { get; set; }
        public string Apikey { get; set; }
        public string ApiSecret { get; set; }
    }
}
