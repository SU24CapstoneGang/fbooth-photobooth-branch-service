﻿namespace PhotoboothBranchService.Domain.Enum
{
    public enum AccountRole
    {
        Admin = 1,
        Staff = 2,
        Customer = 3,
    }
}
