﻿namespace PhotoboothBranchService.Domain
{
    public enum ServiceType
    {
        Printing = 1,
        EmailSending = 2,
        ClothingRental = 3,
        Drinking = 4,
        MakeupKitRental = 5,
        Other = 6,
    }
}