﻿namespace PhotoboothBranchService.Domain.Enum
{
    public enum PhotoSessionStatus
    {
        Ongoing = 1, // customer in take photo session  
        Ended = 2 // after the session ended
    }
}
